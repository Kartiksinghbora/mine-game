// Create an array with 3 bombs and 27 safes
const images = Array(3).fill('bomb.png').concat(Array(27).fill('safe.png'));

// Shuffle the array
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function initializeGame() {
    const gameOverText = document.querySelector('.game-over');
    gameOverText.style.display="none";
    const gameOverSound = document.getElementById('gameOverSound');
    const selectSound = document.getElementById('selectSound');
    const restart = document.getElementById('restart');
    restart.style.display="none";

    // Shuffle the images array
    const shuffledImages = shuffle(images);

    // Select the pattern container
    const patternContainer = document.querySelector('.pattern');
    patternContainer.innerHTML="";
    

    // Create and append boxes with images
    shuffledImages.forEach(image => {
        const box = document.createElement('div');
        box.classList.add('box');
        const img = document.createElement('img');
        img.src = image;
        img.alt = image.includes('bomb') ? 'Bomb' : 'Safe';
        box.appendChild(img);
        patternContainer.appendChild(box);

        box.addEventListener('click', function () {
            selectSound.play();
            img.style.display = 'block';
            

            if (image === 'bomb.png') {
                gameOverText.style.display = 'block';
                restart.style.display = 'inline-block';
                gameOverSound.play();
                const boxes = document.querySelectorAll('.box');
                boxes.forEach(box => box.style.pointerEvents = "none");
            }


        });
    });
}

initializeGame();
document.getElementById('restart').addEventListener('click',initializeGame);

